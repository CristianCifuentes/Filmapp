package com.example.filmapp1;

//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

//import com.example.filmapp1.controlador.GaleriaPeliculas;
import com.example.filmapp1.controlador.PeliculasFav;

public class MisPeliculasActivity extends AppCompatActivity {

    GridView gridViewImagenesFav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mis_peliculas);


        gridViewImagenesFav = findViewById(R.id.gvImagenesFav);
        gridViewImagenesFav.setAdapter(new PeliculasFav(this));

    }

}