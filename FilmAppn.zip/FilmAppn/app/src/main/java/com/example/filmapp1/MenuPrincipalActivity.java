package com.example.filmapp1;

import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPrincipalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);
    }

    public void regresar(View view){
        Intent regresar = new Intent(MenuPrincipalActivity.this, LoginActivity.class);
        startActivity(regresar);
    }

    public void peliculas(View view){
        Intent peli = new Intent(MenuPrincipalActivity.this, Pelicula.class);
        //Intent peli = new Intent(MenuPrincipalActivity2.this, PeliculasActivity.class);
        startActivity(peli);
    }

    public void peliculasFav(View view){
        Intent peliFav = new Intent(MenuPrincipalActivity.this, MisPeliculasActivity.class);
        startActivity(peliFav);
    }


}