package com.example.filmapp1;

import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        EditText etCorreo = findViewById(R.id.etcorreo);
        EditText etContra = findViewById(R.id.etpassword);
        Button btnInicioSesion = findViewById(R.id.btnIniciarSesion);


        btnInicioSesion.setOnClickListener(View ->{

            String correo= etCorreo.getText().toString();
            String contra =etContra.getText().toString();

            if ("admin@admin".equals(correo) && "admin".equals(contra)){
                Intent iniciar = new Intent(LoginActivity.this, MenuPrincipalActivity.class);
                startActivity(iniciar);
            }
            else {
                Toast.makeText(this,"Caracter invalido", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public  void menu (View view){
        Intent ini = new Intent(LoginActivity.this, MenuPrincipalActivity.class);
        startActivity(ini);
    }

    public  void registro (View view){
        Intent registr = new Intent(LoginActivity.this, RegistroActivity.class);
        startActivity(registr);
    }




}