package com.example.filmapp1;

import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.filmapp1.modelo.Cliente;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class RegistroActivity extends AppCompatActivity {


    //Declaración de variables
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;


    //private EditText uId;
    //private EditText documento;
    private EditText nombre;
    private EditText apellido;
    private EditText correo;
    private EditText contrasena;
    private ListView listv_estudiantes;

    private final List<Cliente> listCliente=new ArrayList<>();
    ArrayAdapter<Cliente> clienteArrayAdapter;
    Cliente clienteSelected;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        nombre=(EditText)findViewById(R.id.txtNombre);
        apellido=(EditText)findViewById(R.id.txtApellido);
        correo=(EditText)findViewById(R.id.txtCorreo);
        contrasena=(EditText)findViewById(R.id.txtContra);
        listv_estudiantes=(ListView) findViewById(R.id.lvdatosClientes);

        inicializarBD();
        listarDatos();
        listv_estudiantes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                clienteSelected=(Cliente) adapterView.getItemAtPosition(i);
                nombre.setText(clienteSelected.getNombre());
                //documento.setText(clienteSelected.getDocumento());
                apellido.setText(clienteSelected.getApellido());
                correo.setText(clienteSelected.getCorreo());
                contrasena.setText(clienteSelected.getContrasena());
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_clientes, menu);
        return super.onCreateOptionsMenu(menu);

    }

    private void inicializarBD(){
        //Llamado a la BD
        FirebaseApp.initializeApp(this);
        firebaseDatabase= FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
        Toast.makeText(this, "Inicializando Base de Datos", Toast.LENGTH_SHORT).show();
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        //String documentoE=documento.getText().toString();
        String nombreC=nombre.getText().toString();
        String apellidoC=apellido.getText().toString();
        String correoC=correo.getText().toString();
        String contrasenaC=contrasena.getText().toString();

        switch (item.getItemId()) {
            case R.id.icono_nuevo:
                if (nombreC.isEmpty() ||  (apellidoC.isEmpty()) || (correoC.isEmpty() || (contrasenaC.isEmpty()))){
                    validacion();
                }
                else {
                    Cliente objEstu =new Cliente();
                    //objEstu.setDocumento(documentoE);
                    objEstu.setNombre(nombreC);
                    objEstu.setApellido(apellidoC);
                    objEstu.setCorreo(correoC);
                    objEstu.setContrasena(contrasenaC);
                    databaseReference.child("estudiante").child(objEstu.getApellido()).setValue(objEstu);
                    Toast.makeText(this, "Registro agregado corrrectamente", Toast.LENGTH_LONG).show();
                    limpiarCajas();
                }
                break;
            case  R.id.icono_actualizar:
                Toast.makeText(this, "Actualizado", Toast.LENGTH_SHORT).show();
                break;
            case R.id.icono_eliminar:
                Toast.makeText(this, "Eliminado", Toast.LENGTH_SHORT).show();
                break;
            case R.id.icono_regresar:
                Toast.makeText(this, "Inicio", Toast.LENGTH_SHORT).show();
                Intent btnEstudiante =new Intent(this, LoginActivity.class);
                startActivity(btnEstudiante);

                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }



    private void limpiarCajas(){
        //documento.setText("");
        nombre.setText("");
        apellido.setText("");
        correo.setText("");
        contrasena.setText("");
    }

    private void validacion(){
        //String documentoE =documento.getText().toString();
        String nombreC =nombre.getText().toString();
        String apellidoC =apellido.getText().toString();
        String correoC =correo.getText().toString();
        String contrasenaC =contrasena.getText().toString();
        if (nombreC.isEmpty()){
            nombre.setError("Requerido");
        } else if (apellidoC.isEmpty()){
            apellido.setError("Requerido");
        } else if (correoC.isEmpty()){
            correo.setError("Requerido");
        } else {
            contrasena.setError("Requerido");
        }
    }


    public void listarDatos(){
        databaseReference.child("cliente").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listCliente.clear();
                for(DataSnapshot objSnapshot:snapshot.getChildren()){
                    Cliente e=objSnapshot.getValue(Cliente.class);
                    listCliente.add(e);
                    clienteArrayAdapter=new ArrayAdapter<Cliente>(RegistroActivity.this, android.R.layout.simple_list_item_1,listCliente);
                    listv_estudiantes.setAdapter(clienteArrayAdapter);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void volver(View view){
        Intent regisU = new Intent(RegistroActivity.this, LoginActivity.class);
        startActivity(regisU);
    }
}