package com.example.filmapp1;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
//import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Animation animacion1= AnimationUtils.loadAnimation(this,R.anim.dezparriba);
        Animation animacion2= AnimationUtils.loadAnimation(this,R.anim.dezpabajo);

        TextView FilmAppTextView = findViewById(R.id.FilmAppTextView);
        ImageView imageViewFilmApp = findViewById(R.id.imageViewFilmApp);

        FilmAppTextView.setAnimation(animacion2);
        imageViewFilmApp.setAnimation(animacion1);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);

                Pair[] pairs=new Pair[2];
                pairs[0] =new Pair<View, String>(imageViewFilmApp, "logoImagenTrans");
                pairs[1] =new Pair<View, String>(FilmAppTextView, "textTrans");

                if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
                    ActivityOptions options=ActivityOptions.makeSceneTransitionAnimation(MainActivity.this, pairs);
                    startActivity(intent, options.toBundle());
                }else {
                    startActivity(intent);
                    finish();
                }
                // startActivity(intent);
                // finish();
            }
        }, 4000);



    }
}